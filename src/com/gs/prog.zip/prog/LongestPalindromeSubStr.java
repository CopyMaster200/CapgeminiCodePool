/*
 * Candidate: 
 * Click `Run` to execute the snippet below!
 */
package com.gs.prog;

import java.util.Stack;

/* 
* Problem Statement: Longest Palindrome substring
Input: Given string :"forgeeksskeegfor", 
Output: "geeksskeeg"
**/

class LongestPalindromeSubStr {

	public static void main(String[] args) {
		String str = "Geeks";// "forgeeksskeegfor";
		Stack<Character> stk = new Stack<>();
		int len = str.length();
		// System.out.println(len/2);
		for (int i = 0; i < (len / 2); i++) {
			stk.push(str.charAt(i));
		}
		int mark = 0, end = 0;
		for (int j = len / 2; j < len; j++) {
			if (stk.peek() == str.charAt(j)) {
				// System.out.println(stk.pop());
				stk.pop();
				mark = j;
			} else {
				end = j;
				break;
			}
		}
		if (mark <= 0) {
			System.out.println("Palindrome not found");
		} else {
			System.out.println(str.substring(mark - 1, end));
		}
	}
}