package com.gs.prog;

public class ProbabilityForSumN {
	public static void main(String[] args) {
		int target = 3;
		probabilityOfSum(target);
	}

	private static void probabilityOfSum(int target) {
		int temp = target;
		for(int i=1;i<=target;i++) {
			
		}
		System.out.println(target);
	}
}
